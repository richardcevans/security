locals {
  genai_compartment_ocid = var.genai_policy_compartment_ocid != "" ? var.genai_policy_compartment_ocid : var.compartment_ocid
}
