# Vibe CLI - OCI Generative AI Lab Coding Assistant

`vibe` is a small constrained coding assistant for the Deep Data Security hands-on lab. It uses OCI Generative AI through the same instance-principal and `generative-ai-chat` path as the existing Flask application.

It does not require external coding-assistant subscriptions or student API keys.

## Modifying the supplied starter application

This lab starts with the supplied, known-good Oracle Customer Sales application. Vibe modifies that existing application only after the baseline, employee, and manager authorization demonstrations.


## Install

```bash
unzip -o vibe-cli.zip
cd vibe-cli
./install.sh --overwrite
```

The installer preserves `~/.config/vibe/config.toml` on overwrite and migrates the legacy `/home/opc/customer-app` project path to `/home/opc/deepsec9-lab/flask-app`. Use `--overwrite-config` to replace the full configuration with the packaged default.

## OCI GenAI configuration

By default Vibe reads:

```text
/home/opc/.deepsec9-genai-defaults
```

with values such as:

```bash
OCI_REGION="us-ashburn-1"
GENAI_COMPARTMENT_OCID="ocid1.compartment..."
GENAI_MODEL_ID="google.gemini-2.5-flash"
```

The compute instance authenticates with its OCI instance principal.

## Lab coding context

Every coding request automatically includes:

```text
/home/opc/vibe-agent/lab-context.md
```

The packaged context pins the Deep Data Security lab to:

```text
TNS_ADMIN=/home/opc/deepsec9-wallet/tns_admin
DSN=deepsec9_low
Flask host=0.0.0.0
Flask port=7777 (required; do not change it)
```

It also tells the model to authenticate to Oracle as the username/password entered by the participant, to use `oracledb`, and to leave row/column authorization to Deep Data Security rather than implementing security filters in Flask. You can edit `~/vibe-agent/lab-context.md` after installation without changing the Python code. Set `VIBE_LAB_CONTEXT` only if you intentionally want to point Vibe at a different context file.

## Application configuration

Edit:

```bash
vi ~/.config/vibe/config.toml
```

Example:

```toml
project_root = "/home/opc/deepsec9-lab/flask-app"
backup_root = "/home/opc/.vibe-backups"
known_good_root = "/home/opc/deepsec9-lab/customer-sales-known-good"
max_file_bytes = 200000
max_project_bytes = 500000
max_output_tokens = 16000
```

`project_root` must already exist.


## Starter application runtime

Vibe modifies the supplied application at:

```text
/home/opc/deepsec9-lab/flask-app
```

Stop the running server before approving changes, then restart it with `./run.sh` from that directory.

Vibe is intentionally allowed to implement requested data features, including searches, exports, and pages that ask for all customers or fields. It uses the signed-in database user's connection; Oracle Database remains responsible for the rows and columns returned.

The starter application uses `setup_venv.sh`, not `setup.sh`. Run `bash setup_venv.sh` only when an approved Vibe change modifies `requirements.txt` or `setup_venv.sh`; a normal UI change such as customer search needs only `./run.sh` after approval.

## Student commands

Modify the application:

```bash
vibe "Add a low-stock dashboard"
```

Vibe shows the proposed diff before applying it. When changes are approved, it automatically creates a complete filesystem backup first.

## Troubleshooting GenAI output

Vibe requires OCI Generative AI to return complete-file blocks. If a response is malformed or incomplete, Vibe automatically saves the raw response and OCI response metadata in an owner-only file under `~/.vibe-traces/` and prints its path. To save a trace for every successful and failed request, run:

```bash
VIBE_TRACE=1 vibe "Add a customer search box"
```

Trace files can contain proposed source-code changes. They never contain the participant's database password, wallet, or `.env` file, but do not share them outside the lab without review.

Create a manual backup:

```bash
vibe backup
```

Restore the most recent backup:

```bash
vibe restore
```

Restore the protected known-good copy:

```bash
vibe reset
```

Show configuration:

```bash
vibe status
```

## Backup behavior

Backups are stored as timestamped directories under:

```text
/home/opc/.vibe-backups/
```

A typical sequence is:

```text
student prompt -> OCI GenAI -> proposed diff -> approval -> filesystem backup -> apply changes
```

No source-control system is required.

## Safety

Vibe can only inspect and modify text files under `project_root`. It rejects path traversal and blocks common secrets and wallet material including `.env`, private keys, `cwallet.sso`, `ewallet.p12`, `sqlnet.ora`, and `tnsnames.ora`.

The model has no shell, `sudo`, SQL*Plus, OCI CLI, or arbitrary command-execution tool.

## Known-good fallback

For workshop reliability, keep a complete working application in a separate directory, for example:

```text
/home/opc/deepsec9-lab/customer-sales-known-good
```

Then `vibe reset` replaces the current application with that copy. Before reset, Vibe first backs up the current application.

## Uninstall

Preserve config:

```bash
./uninstall.sh
```

Remove config too:

```bash
./uninstall.sh --purge-config
```

## Oracle lab runtime defaults

The installed `~/vibe-agent/lab-context.md` instructs Vibe modifications to preserve python-oracledb Thick mode with Oracle Instant Client, `config_dir=/home/opc/deepsec9-wallet/tns_admin`, and DSN `deepsec9_low`. The application must not use the PEM-based Thin-mode wallet path or prompt for a wallet pass phrase. Vibe is also instructed to preserve useful terminal diagnostics without logging passwords.

## Managed application cleanup

After Vibe successfully applies changes to an application, it records the app in:

```text
/home/opc/vibe-agent/apps.json
```

and creates a `.vibe-managed` safety marker inside that app directory.

List managed apps:

```bash
vibe apps
```

Delete the currently configured managed app:

```bash
vibe clean
```

Delete it plus its Vibe backups:

```bash
vibe clean --backups
```

Delete all registered managed apps:

```bash
vibe clean --all
```

Non-interactive lab cleanup:

```bash
vibe clean --all --backups --yes
```

For safety, Vibe refuses to delete an app unless it is both registered and contains the `.vibe-managed` marker. It also refuses to delete `/`, the user's home directory, or applications outside the user's home directory.
