#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
VIBE_HOME="${VIBE_HOME:-$HOME/vibe-agent}"
BIN_DIR="${VIBE_BIN_DIR:-$HOME/bin}"
CONFIG_DIR="${VIBE_CONFIG_DIR:-$HOME/.config/vibe}"
CONFIG_FILE="$CONFIG_DIR/config.toml"
PYTHON_BIN="${PYTHON_BIN:-python3}"
OVERWRITE=0
OVERWRITE_CONFIG=0

usage() {
  cat <<USAGE
Usage: ./install.sh [--overwrite] [--overwrite-config] [--help]

Options:
  --overwrite         Reinstall Vibe even if it is already installed.
                      Existing program files and virtual environment are replaced.
                      The existing config.toml is preserved.
  --overwrite-config  Replace config.toml with the package default.
                      Implies --overwrite.
  -h, --help          Show this help.

Environment overrides:
  VIBE_HOME           Install directory (default: $HOME/vibe-agent)
  VIBE_BIN_DIR        Command directory (default: $HOME/bin)
  VIBE_CONFIG_DIR     Config directory (default: $HOME/.config/vibe)
  PYTHON_BIN          Python executable (default: python3)
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --overwrite)
      OVERWRITE=1
      ;;
    --overwrite-config)
      OVERWRITE=1
      OVERWRITE_CONFIG=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown option: %s\n\n' "$1" >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

if [[ -e "$VIBE_HOME" || -e "$BIN_DIR/vibe" ]]; then
  if [[ "$OVERWRITE" -ne 1 ]]; then
    cat >&2 <<ERROR
Vibe appears to be installed already.

Reinstall it with:
  ./install.sh --overwrite

This replaces the Vibe program and virtual environment but preserves:
  $CONFIG_FILE
ERROR
    exit 1
  fi

  printf 'Overwriting existing Vibe installation...\n'
  rm -rfv "$VIBE_HOME"
  rm -fv "$BIN_DIR/vibe"
fi

mkdir -pv "$VIBE_HOME" "$BIN_DIR" "$CONFIG_DIR"
cp -Rv "$SRC_DIR/vibe_agent" "$VIBE_HOME/"
cp -v "$SRC_DIR/requirements.txt" "$VIBE_HOME/requirements.txt"
cp -v "$SRC_DIR/lab-context.md" "$VIBE_HOME/lab-context.md"

"$PYTHON_BIN" -m venv "$VIBE_HOME/.venv"
"$VIBE_HOME/.venv/bin/python" -m pip install --upgrade pip
"$VIBE_HOME/.venv/bin/python" -m pip install -r "$VIBE_HOME/requirements.txt"

cat > "$BIN_DIR/vibe" <<'WRAPPER'
#!/usr/bin/env bash
set -euo pipefail
VIBE_HOME="${VIBE_HOME:-$HOME/vibe-agent}"
export PYTHONPATH="$VIBE_HOME${PYTHONPATH:+:$PYTHONPATH}"
exec "$VIBE_HOME/.venv/bin/python" -m vibe_agent.cli "$@"
WRAPPER
chmod +x "$BIN_DIR/vibe"

if [[ "$OVERWRITE_CONFIG" -eq 1 || ! -f "$CONFIG_FILE" ]]; then
  cp -v "$SRC_DIR/config.example.toml" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
  if [[ "$OVERWRITE_CONFIG" -eq 1 ]]; then
    printf 'Config replaced: %s\n' "$CONFIG_FILE"
  fi
else
  # Migrate the legacy workshop project path when preserving a prior config.
  if grep -Fqx 'project_root = "/home/opc/customer-app"' "$CONFIG_FILE"; then
    sed -i 's|^project_root = "/home/opc/customer-app"$|project_root = "/home/opc/deep-sec-lab/flask-app"|' "$CONFIG_FILE"
    sed -i 's|^known_good_root = "/home/opc/customer-app-known-good"$|known_good_root = "/home/opc/deep-sec-lab/customer-sales-known-good"|' "$CONFIG_FILE"
    printf 'Migrated legacy project root: %s\n' "$CONFIG_FILE"
  fi
  printf 'Config preserved: %s\n' "$CONFIG_FILE"
fi

printf '\nInstalled: %s\n' "$BIN_DIR/vibe"
printf 'Home:      %s\n' "$VIBE_HOME"
printf 'Config:    %s\n' "$CONFIG_FILE"
printf '\nEnsure %s is on PATH, then run: vibe --help\n' "$BIN_DIR"
