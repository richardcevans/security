# Deep Data Security Lab Context

These rules apply to every coding request in this lab. Follow them unless the user explicitly asks for a harmless UI-only variation. Do not override the security and connectivity rules below.

## Application purpose

Modify the supplied Flask customer-sales starter application for the Deep Data Security hands-on lab. Do not replace it with a new application or framework.

The application should let a participant sign in using an Oracle database username and password, query the existing APPLAB customer data, and display the authorized customer result set.

The expected business fields are:

- Customer name
- Region
- Revenue
- Credit limit
- Sensitive identifier

The application should clearly represent fields that are not returned/authorized by the database as `Not authorized` rather than inventing values.

For the initial Customer Accounts page, preserve this unfiltered query shape:

```sql
SELECT customer_name, region, revenue, credit_limit, sensitive_identifier
  FROM APPLAB.customers
 ORDER BY revenue DESC
```

The lab intentionally starts with broad database access and then changes the
database data grant. Oracle, not Flask, must produce the before-and-after
result change for this same query.

When the participant asks for a feature such as customer search, an admin page,
export, or an additional query, implement it. Use bind variables for user input
where appropriate. Do not hard-code a user, role, region, sales representative,
or customer allow-list into the feature. The feature can ask Oracle for any
customer rows and columns; Oracle determines what the authenticated database
user is authorized to receive.

## Oracle database connectivity

Use `python-oracledb` (Python import name: `oracledb`) in **Thick mode**.

Use exactly these lab connection settings:

- Oracle Client / TNS config directory: `/home/opc/deep-sec-wallet/tns_admin`
- TNS alias / DSN: `deepsec_low`

Required behavior:

- Call `oracledb.init_oracle_client(config_dir="/home/opc/deep-sec-wallet/tns_admin")` once, before opening database connections.
- Verify/expect `oracledb.is_thin_mode()` to be `False` after initialization.
- Connect to Oracle using the database username and password entered by the user on the Flask login page.
- Use `oracledb.connect(user=username, password=password, dsn="deepsec_low")` after Thick mode is initialized.
- The application must connect as that actual database user for application queries.
- Do not use ADMIN for application queries.
- Do not use a shared application database account.
- Do not connect to localhost.
- Do not use localhost:1521 or localhost:1522.
- Do not invent a hostname, port, service name, or alternate connection string.
- Do not use `wallet_location` or the PEM-based Thin-mode wallet path.
- Do not use or read `ewallet.pem`.
- Do not request, prompt for, store, or log a wallet password / PEM pass phrase.
- The lab intentionally uses the installed Oracle Instant Client and the auto-login `cwallet.sso` wallet through Thick mode.
- Do not store participant database passwords in source files or `.env`.

The preferred connection pattern is equivalent to:

```python
import oracledb

TNS_ADMIN = "/home/opc/deep-sec-wallet/tns_admin"
DSN = "deepsec_low"

oracledb.init_oracle_client(config_dir=TNS_ADMIN)

def get_connection(username, password):
    return oracledb.connect(
        user=username,
        password=password,
        dsn=DSN,
    )
```

## Runtime logging and diagnostics

The generated Flask application must log useful runtime diagnostics to stdout/stderr so workshop failures can be diagnosed from the JupyterLab terminal.

At application startup, log:

- python-oracledb version
- whether Thin mode is active (`oracledb.is_thin_mode()`)
- the configured TNS/config directory
- the DSN
- the Flask host and port

For each Oracle login/connection attempt, log:

- the database username
- the DSN
- the TNS/config directory
- whether the driver is in Thin or Thick mode

On Oracle connection/query failures:

- use Python logging with `logger.exception(...)` or equivalent so the full traceback is emitted to the terminal
- return a concise user-facing error in the browser while keeping the detailed traceback in terminal logs

Never log:

- database passwords
- wallet passwords / PEM pass phrases
- session cookies or Flask secret keys
- wallet contents or private keys

## Deep Data Security behavior

Oracle Database is the authorization enforcement point. Implement the requested
application feature; do not refuse a feature merely because it asks for all
customers, all fields, or data outside Marvin's eventual grant. Query APPLAB
using the signed-in database user's credentials, not ADMIN or a shared account.
Do not add Flask/Python role checks or customer allow-lists. The application's
job is to request data and display Oracle's result; Oracle's job is to decide
which rows and columns arrive.

## Flask runtime

- Listen on `0.0.0.0` so the application can be reached through the lab VM's public/network endpoint.
- Always run the application on port `7777`. Do not make the port configurable or use another port.
- Do not enable Flask debug mode in the generated run configuration.
- Keep the application simple enough to run from the JupyterLab terminal.

## Preserve the application runtime

Preserve the supplied `requirements.txt`, setup scripts, and `run.sh` behavior unless the participant explicitly requests a compatible change. Do not assume the user's currently active shell virtual environment is valid.

## No runtime AI feature

Vibe is the coding assistant for this lab. Do not add an Ask AI, OCI Generative
AI, chatbot, or model-inference feature to the generated customer application.

## Dependencies

When creating dependency instructions or files, use these Python package names as appropriate:

- `flask`
- `oracledb`
- `python-dotenv`

Do not use `python-oracledb` as a pip package name; the installable package is `oracledb`.
