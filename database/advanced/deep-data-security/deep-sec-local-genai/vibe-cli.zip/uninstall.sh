#!/usr/bin/env bash
set -euo pipefail

VIBE_HOME="${VIBE_HOME:-$HOME/vibe-agent}"
BIN_DIR="${VIBE_BIN_DIR:-$HOME/bin}"
CONFIG_DIR="${VIBE_CONFIG_DIR:-$HOME/.config/vibe}"
CONFIG_FILE="$CONFIG_DIR/config.toml"
PURGE_CONFIG=0
YES=0

usage() {
  cat <<USAGE
Usage: ./uninstall.sh [--purge-config] [--yes] [--help]

Options:
  --purge-config  Also remove $CONFIG_FILE.
                  By default, configuration is preserved for a later reinstall.
  -y, --yes       Do not prompt for confirmation.
  -h, --help      Show this help.

Environment overrides:
  VIBE_HOME        Install directory (default: $HOME/vibe-agent)
  VIBE_BIN_DIR     Command directory (default: $HOME/bin)
  VIBE_CONFIG_DIR  Config directory (default: $HOME/.config/vibe)
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge-config)
      PURGE_CONFIG=1
      ;;
    -y|--yes)
      YES=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown option: %s\n\n' "$1" >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

# Refuse obviously dangerous install directory values before rm -rf.
case "$VIBE_HOME" in
  ""|"/"|"$HOME")
    printf 'Refusing to uninstall: unsafe VIBE_HOME value: %s\n' "$VIBE_HOME" >&2
    exit 1
    ;;
esac

printf 'Vibe uninstall will remove:\n'
printf '  %s\n' "$VIBE_HOME"
printf '  %s\n' "$BIN_DIR/vibe"
if [[ "$PURGE_CONFIG" -eq 1 ]]; then
  printf '  %s\n' "$CONFIG_FILE"
else
  printf 'Config will be preserved:\n  %s\n' "$CONFIG_FILE"
fi

if [[ "$YES" -ne 1 ]]; then
  printf '\nContinue? [y/N] '
  read -r answer
  case "$answer" in
    y|Y|yes|YES|Yes) ;;
    *)
      printf 'Uninstall cancelled.\n'
      exit 0
      ;;
  esac
fi

if [[ -e "$VIBE_HOME" ]]; then
  rm -rfv "$VIBE_HOME"
  printf 'Removed: %s\n' "$VIBE_HOME"
else
  printf 'Not found: %s\n' "$VIBE_HOME"
fi

if [[ -e "$BIN_DIR/vibe" || -L "$BIN_DIR/vibe" ]]; then
  rm -fv "$BIN_DIR/vibe"
  printf 'Removed: %s\n' "$BIN_DIR/vibe"
else
  printf 'Not found: %s\n' "$BIN_DIR/vibe"
fi

if [[ "$PURGE_CONFIG" -eq 1 ]]; then
  if [[ -e "$CONFIG_FILE" ]]; then
    rm -fv "$CONFIG_FILE"
    printf 'Removed: %s\n' "$CONFIG_FILE"
  else
    printf 'Not found: %s\n' "$CONFIG_FILE"
  fi
  rmdir -v "$CONFIG_DIR" 2>/dev/null || true
else
  printf 'Preserved config: %s\n' "$CONFIG_FILE"
fi

printf '\nVibe has been uninstalled.\n'
