from __future__ import annotations

import json
import os
import re
from datetime import UTC, datetime
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import oci

from .config import Config
from .sandbox import ProjectSandbox, SandboxError


SYSTEM_INSTRUCTIONS = """You are Vibe, a constrained coding assistant in a hands-on lab.
You are given the current text files from a small application and a student's requested change.

Rules:
- Make the smallest coherent change that satisfies the request.
- Preserve direct database authentication as the signed-in end user.
- Follow the supplied lab context exactly for Oracle connectivity, including python-oracledb Thick mode, the configured TNS directory/DSN, and runtime logging.
- Never switch the generated app to python-oracledb Thin mode or a PEM/wallet-password flow.
- Implement requested data features against the database using the signed-in user's connection. Do not add application-side customer authorization filters; Oracle Database determines the rows and columns returned.
- Never request secrets, wallets, tokens, .env contents, private keys, or files outside the supplied project snapshot.
- Do not invent unrelated infrastructure changes.
- You cannot run shell commands or access files not included in the prompt.
- Return the response in this exact plain-text format. Do not return JSON and do not wrap the response in Markdown fences:

SUMMARY: short explanation of the changes
=== FILE: relative/project/file ===
complete replacement UTF-8 file contents
=== END FILE ===

Repeat the FILE block for every file that changes. For a new or existing file, provide its complete replacement contents. If no file changes are needed, return only the SUMMARY line.
"""


def _load_lab_context() -> str:
    context_path = Path.home() / "vibe-agent" / "lab-context.md"
    override = __import__("os").environ.get("VIBE_LAB_CONTEXT")
    if override:
        context_path = Path(override).expanduser()
    if not context_path.exists():
        return ""
    try:
        return context_path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise RuntimeError(f"Unable to read lab context: {context_path}: {exc}") from exc


@dataclass
class AgentResult:
    summary: str
    sandbox: ProjectSandbox
    calls: int


def _client(config: Config):
    signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
    endpoint = f"https://inference.generativeai.{config.region}.oci.oraclecloud.com"
    return oci.generative_ai_inference.GenerativeAiInferenceClient(
        config={},
        signer=signer,
        service_endpoint=endpoint,
    )


def _project_snapshot(sandbox: ProjectSandbox, max_project_bytes: int) -> str:
    chunks: list[str] = []
    total = 0
    included = 0
    skipped: list[str] = []

    for rel in sandbox.list_files():
        try:
            content = sandbox.read_file(rel)
        except SandboxError:
            continue
        encoded_len = len(content.encode("utf-8"))
        header = f"\n--- FILE: {rel} ---\n"
        cost = len(header.encode("utf-8")) + encoded_len
        if total + cost > max_project_bytes:
            skipped.append(rel)
            continue
        chunks.append(header + content)
        total += cost
        included += 1

    if not chunks:
        return (
            "The project directory currently contains no readable text files. "
            "Treat this as a new application and create the files required to satisfy the student request.\n"
        )

    note = f"Included {included} files ({total} bytes)."
    if skipped:
        note += " Skipped due to snapshot limit: " + ", ".join(skipped)
    return note + "\n" + "".join(chunks)


def _extract_response_text(chat_result: Any) -> str:
    """Extract text from a GenericChatResponse without depending on provider-specific internals."""
    chat_response = getattr(chat_result, "chat_response", None)
    choices = getattr(chat_response, "choices", None) or []
    texts: list[str] = []
    for choice in choices:
        message = getattr(choice, "message", None)
        content = getattr(message, "content", None) or []
        for item in content:
            text = getattr(item, "text", None)
            if text:
                texts.append(text)
    if texts:
        return "\n".join(texts)

    # Defensive fallback for SDK/provider shape changes.
    try:
        data = oci.util.to_dict(chat_result)
    except Exception as exc:  # pragma: no cover - only used against a live SDK response
        raise RuntimeError("OCI GenAI returned an unreadable response.") from exc

    def walk(value: Any) -> list[str]:
        found: list[str] = []
        if isinstance(value, dict):
            if isinstance(value.get("text"), str):
                found.append(value["text"])
            for child in value.values():
                found.extend(walk(child))
        elif isinstance(value, list):
            for child in value:
                found.extend(walk(child))
        return found

    texts = walk(data)
    if not texts:
        raise RuntimeError("OCI GenAI returned no text content.")
    return "\n".join(texts)


def _parse_agent_response(text: str) -> dict[str, Any]:
    """Parse the file-block protocol without embedding source code in JSON strings."""
    candidate = text.strip()
    if candidate.startswith("```"):
        candidate = re.sub(r"^```(?:text)?\s*", "", candidate, flags=re.IGNORECASE)
        candidate = re.sub(r"\s*```$", "", candidate)
    summary_match = re.search(r"(?m)^SUMMARY:\s*(.+)$", candidate)
    if not summary_match:
        raise RuntimeError("OCI GenAI did not return the required SUMMARY line.")
    summary = summary_match.group(1).strip()
    header_pattern = re.compile(r"(?m)^=== FILE: ([^\r\n]+) ===\r?\n")
    headers = list(header_pattern.finditer(candidate))
    changes = []
    for index, header in enumerate(headers):
        next_start = headers[index + 1].start() if index + 1 < len(headers) else len(candidate)
        content = candidate[header.end() : next_start]
        # The explicit terminator is preferred. Some models omit it despite
        # otherwise returning complete files, so the next FILE header (or the
        # end of the response) is also a safe boundary.
        content = re.sub(r"\r?\n=== END FILE ===\s*$", "", content)
        changes.append({"path": header.group(1).strip(), "content": content.rstrip()})
    return {"summary": summary, "changes": changes}


def _parse_legacy_json_response(text: str) -> dict[str, Any] | None:
    """Accept a fully valid legacy response; never scan nested source-code objects."""
    candidate = text.strip()
    if candidate.startswith("```"):
        candidate = re.sub(r"^```(?:json)?\s*", "", candidate, flags=re.IGNORECASE)
        candidate = re.sub(r"\s*```$", "", candidate)
    try:
        value = json.loads(candidate)
    except json.JSONDecodeError:
        return None
    if not isinstance(value, dict) or not isinstance(value.get("summary"), str) or not isinstance(value.get("changes"), list):
        return None
    return value


def _write_trace(config: Config, request: str, response_text: str, response_data: Any) -> Path:
    """Write a local, owner-only diagnostic record without logging credentials."""
    trace_dir = Path(os.environ.get("VIBE_TRACE_DIR", "~/.vibe-traces")).expanduser()
    trace_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    trace_dir.chmod(0o700)
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    trace_path = trace_dir / f"vibe-genai-{timestamp}.json"
    try:
        response_metadata = oci.util.to_dict(response_data)
    except Exception:
        response_metadata = {"unavailable": True}
    record = {
        "timestamp_utc": timestamp,
        "project_root": str(config.project_root),
        "model": config.model,
        "region": config.region,
        "request": request,
        "raw_response_text": response_text,
        "response_metadata": response_metadata,
    }
    trace_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    trace_path.chmod(0o600)
    return trace_path


def run_agent(config: Config, request: str) -> AgentResult:
    sandbox = ProjectSandbox(config.project_root, config.max_file_bytes)
    snapshot = _project_snapshot(sandbox, config.max_project_bytes)
    lab_context = _load_lab_context()
    context_block = ""
    if lab_context:
        context_block = f"Lab-specific requirements (mandatory):\n{lab_context}\n\n"
    prompt = (
        context_block
        + f"Student request:\n{request}\n\n"
        + f"Project root label: {config.project_root.name}\n"
        + f"Project snapshot:\n{snapshot}\n\n"
        + "Return the required plain-text SUMMARY and FILE blocks with complete contents for every file that should be created or changed."
    )

    models = oci.generative_ai_inference.models
    chat_details = models.ChatDetails(
        compartment_id=config.compartment_ocid,
        serving_mode=models.OnDemandServingMode(serving_type="ON_DEMAND", model_id=config.model),
        chat_request=models.GenericChatRequest(
            api_format="GENERIC",
            messages=[
                models.SystemMessage(content=[models.TextContent(text=SYSTEM_INSTRUCTIONS)]),
                models.UserMessage(content=[models.TextContent(text=prompt)]),
            ],
            is_stream=False,
            temperature=0.2,
            max_tokens=config.max_output_tokens,
        ),
    )

    response = _client(config).chat(chat_details=chat_details)
    text = _extract_response_text(response.data)
    trace_path = None
    if os.environ.get("VIBE_TRACE", "").lower() in {"1", "true", "yes"}:
        trace_path = _write_trace(config, request, text, response.data)
        print(f"Vibe trace saved: {trace_path}")
    try:
        payload = _parse_agent_response(text)
    except RuntimeError as exc:
        legacy_payload = _parse_legacy_json_response(text)
        if legacy_payload is None:
            if trace_path is None:
                trace_path = _write_trace(config, request, text, response.data)
            raise RuntimeError(f"{exc} Trace saved to: {trace_path}. Inspect it with: cat {trace_path}") from exc
        payload = legacy_payload

    summary = str(payload.get("summary") or "Changes proposed by OCI Generative AI.")
    changes = payload.get("changes", [])
    if not isinstance(changes, list):
        raise RuntimeError("OCI GenAI JSON field 'changes' must be an array.")

    for change in changes:
        if not isinstance(change, dict):
            raise RuntimeError("Each generated change must be a JSON object.")
        path = change.get("path")
        content = change.get("content")
        if not isinstance(path, str) or not isinstance(content, str):
            raise RuntimeError("Each generated change requires string fields 'path' and 'content'.")
        try:
            sandbox.stage_write(path, content)
        except SandboxError as exc:
            raise RuntimeError(f"Rejected generated change for {path!r}: {exc}") from exc


    return AgentResult(summary=summary, sandbox=sandbox, calls=1)
