from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


class RegistryError(RuntimeError):
    pass


MARKER_NAME = ".vibe-managed"


@dataclass(frozen=True)
class AppRecord:
    path: Path
    created_at: str
    last_modified_at: str


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe_project(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    home = Path.home().resolve()
    if resolved in {Path("/"), home}:
        raise RegistryError(f"Refusing unsafe application path: {resolved}")
    try:
        resolved.relative_to(home)
    except ValueError as exc:
        raise RegistryError(f"Application must be under {home}: {resolved}") from exc
    return resolved


def _load(registry_path: Path) -> dict:
    path = registry_path.expanduser().resolve()
    if not path.exists():
        return {"apps": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RegistryError(f"Could not read app registry {path}: {exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("apps", []), list):
        raise RegistryError(f"Invalid app registry format: {path}")
    return data


def _save(registry_path: Path, data: dict) -> None:
    path = registry_path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def register_app(project_root: Path, registry_path: Path) -> None:
    project = _safe_project(project_root)
    if not project.is_dir():
        raise RegistryError(f"Application directory does not exist: {project}")

    marker = project / MARKER_NAME
    if not marker.exists():
        marker.write_text(
            "Managed by the Deep Data Security lab vibe tool.\n"
            "This marker is required for safe cleanup.\n",
            encoding="utf-8",
        )

    data = _load(registry_path)
    now = _now()
    existing = None
    for item in data["apps"]:
        if item.get("path") == str(project):
            existing = item
            break
    if existing is None:
        data["apps"].append({
            "path": str(project),
            "created_at": now,
            "last_modified_at": now,
        })
    else:
        existing["last_modified_at"] = now
    _save(registry_path, data)


def list_apps(registry_path: Path) -> list[AppRecord]:
    data = _load(registry_path)
    records: list[AppRecord] = []
    for item in data["apps"]:
        try:
            path = _safe_project(Path(item["path"]))
        except (KeyError, RegistryError):
            continue
        records.append(
            AppRecord(
                path=path,
                created_at=str(item.get("created_at", "")),
                last_modified_at=str(item.get("last_modified_at", "")),
            )
        )
    return records


def is_registered(project_root: Path, registry_path: Path) -> bool:
    project = _safe_project(project_root)
    return any(record.path == project for record in list_apps(registry_path))


def remove_registration(project_root: Path, registry_path: Path) -> None:
    project = _safe_project(project_root)
    data = _load(registry_path)
    data["apps"] = [item for item in data["apps"] if item.get("path") != str(project)]
    _save(registry_path, data)


def clean_app(project_root: Path, registry_path: Path) -> Path:
    project = _safe_project(project_root)
    if not is_registered(project, registry_path):
        raise RegistryError(f"Refusing cleanup; application is not registered with Vibe: {project}")
    marker = project / MARKER_NAME
    if not marker.is_file():
        raise RegistryError(
            f"Refusing cleanup; safety marker is missing: {marker}. "
            "Vibe only deletes registered, marked application directories."
        )
    shutil.rmtree(project)
    remove_registration(project, registry_path)
    return project
