from __future__ import annotations

import hashlib
import shutil
from datetime import datetime, timezone
from pathlib import Path


class BackupError(RuntimeError):
    pass


def _safe_root(path: Path, label: str) -> Path:
    resolved = path.expanduser().resolve()
    if str(resolved) in {"/", str(Path.home().resolve())}:
        raise BackupError(f"Refusing unsafe {label}: {resolved}")
    return resolved


def backup_dir_for_project(backup_root: Path, project_root: Path) -> Path:
    project = _safe_root(project_root, "project root")
    base = _safe_root(backup_root, "backup root")
    digest = hashlib.sha256(str(project).encode("utf-8")).hexdigest()[:10]
    return base / f"{project.name}-{digest}"


def create_backup(project_root: Path, backup_root: Path) -> Path:
    project = _safe_root(project_root, "project root")
    backups = backup_dir_for_project(backup_root, project)
    if not project.is_dir():
        raise BackupError(f"Project root does not exist: {project}")
    backups.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    destination = backups / stamp
    counter = 1
    while destination.exists():
        destination = backups / f"{stamp}-{counter}"
        counter += 1
    shutil.copytree(project, destination, symlinks=True)
    return destination


def list_backups(backup_root: Path, project_root: Path) -> list[Path]:
    backups = backup_dir_for_project(backup_root, project_root)
    if not backups.is_dir():
        return []
    return sorted((p for p in backups.iterdir() if p.is_dir()), reverse=True)


def latest_backup(backup_root: Path, project_root: Path) -> Path:
    backups = list_backups(backup_root, project_root)
    if not backups:
        raise BackupError(f"No backups found for {project_root}")
    return backups[0]


def _replace_project(project_root: Path, source: Path) -> None:
    project = _safe_root(project_root, "project root")
    source = _safe_root(source, "restore source")
    if not source.is_dir():
        raise BackupError(f"Restore source does not exist: {source}")
    if not project.is_dir():
        raise BackupError(f"Project root does not exist: {project}")

    # The lab application lives directly under /opt. Its runtime user owns
    # the application contents but not /opt itself, so deleting the project
    # directory fails at the final rmdir. Keep that directory and replace its
    # contents instead.
    for child in project.iterdir():
        if child.is_symlink() or child.is_file():
            child.unlink()
        else:
            shutil.rmtree(child)

    for child in source.iterdir():
        destination = project / child.name
        if child.is_symlink():
            destination.symlink_to(child.readlink())
        elif child.is_dir():
            shutil.copytree(child, destination, symlinks=True)
        else:
            shutil.copy2(child, destination, follow_symlinks=False)


def restore_latest(project_root: Path, backup_root: Path) -> Path:
    source = latest_backup(backup_root, project_root)
    _replace_project(project_root, source)
    return source


def reset_to_known_good(project_root: Path, known_good_root: Path) -> Path:
    source = _safe_root(known_good_root, "known-good root")
    _replace_project(project_root, source)
    return source


def remove_project_backups(project_root: Path, backup_root: Path) -> Path:
    path = backup_dir_for_project(backup_root, project_root)
    if path.exists():
        shutil.rmtree(path)
    return path
