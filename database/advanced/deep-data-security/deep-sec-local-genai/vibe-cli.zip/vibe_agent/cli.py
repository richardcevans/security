from __future__ import annotations

import argparse
import sys

from .agent import run_agent
from .appregistry import RegistryError, clean_app, list_apps, register_app
from .backupops import BackupError, create_backup, remove_project_backups, reset_to_known_good, restore_latest
from .config import load_config


def confirm(prompt: str, default: bool = False) -> bool:
    suffix = " [Y/n] " if default else " [y/N] "
    try:
        answer = input(prompt + suffix).strip().lower()
    except EOFError:
        return default
    if not answer:
        return default
    return answer in {"y", "yes"}


def cmd_backup(args) -> int:
    cfg = load_config(args.project)
    path = create_backup(cfg.project_root, cfg.backup_root)
    print(f"Backup created: {path}")
    return 0


def cmd_restore(args) -> int:
    cfg = load_config(args.project)
    if not args.yes and not confirm("Replace the current application with the most recent Vibe backup?", default=False):
        print("Restore cancelled.")
        return 0
    source = restore_latest(cfg.project_root, cfg.backup_root)
    register_app(cfg.project_root, cfg.registry_path)
    print(f"Restored application from: {source}")
    return 0


def cmd_reset(args) -> int:
    cfg = load_config(args.project)
    if not args.yes and not confirm(
        f"Replace the current application with the known-good copy at {cfg.known_good_root}?", default=False
    ):
        print("Reset cancelled.")
        return 0
    create_backup(cfg.project_root, cfg.backup_root)
    source = reset_to_known_good(cfg.project_root, cfg.known_good_root)
    register_app(cfg.project_root, cfg.registry_path)
    print(f"Application reset from known-good copy: {source}")
    return 0


def cmd_status(args) -> int:
    cfg = load_config(args.project)
    print(f"Project : {cfg.project_root}")
    print(f"Region  : {cfg.region}")
    print(f"Model   : {cfg.model}")
    print(f"GenAI compartment: {cfg.compartment_ocid}")
    print(f"Backups : {cfg.backup_root}")
    print(f"Known-good copy: {cfg.known_good_root}")
    print(f"App registry: {cfg.registry_path}")
    return 0


def cmd_apps(args) -> int:
    cfg = load_config(args.project, require_project=False)
    records = list_apps(cfg.registry_path)
    if not records:
        print("No Vibe-managed applications are registered.")
        return 0
    print("Vibe-managed applications:")
    for record in records:
        state = "present" if record.path.is_dir() else "missing"
        marker = "marked" if (record.path / ".vibe-managed").is_file() else "unmarked"
        print(f"  {record.path}  [{state}, {marker}]  last={record.last_modified_at}")
    return 0


def _clean_one(cfg, project, yes: bool, backups: bool) -> bool:
    if not yes and not confirm(f"Delete Vibe-managed application {project}?", default=False):
        print(f"Skipped: {project}")
        return False
    clean_app(project, cfg.registry_path)
    print(f"Deleted application: {project}")
    if backups:
        path = remove_project_backups(project, cfg.backup_root)
        print(f"Deleted backups: {path}")
    return True


def cmd_clean(args) -> int:
    cfg = load_config(args.project, require_project=not args.all)
    if args.all:
        records = list_apps(cfg.registry_path)
        if not records:
            print("No Vibe-managed applications are registered.")
            return 0
        if not args.yes and not confirm(
            f"Delete all {len(records)} registered Vibe-managed applications?", default=False
        ):
            print("Cleanup cancelled.")
            return 0
        deleted = 0
        for record in list(records):
            try:
                if _clean_one(cfg, record.path, True, args.backups):
                    deleted += 1
            except RegistryError as exc:
                print(f"Skipped {record.path}: {exc}", file=sys.stderr)
        print(f"Cleaned {deleted} application(s).")
        return 0

    _clean_one(cfg, cfg.project_root, args.yes, args.backups)
    return 0


def cmd_vibe(args) -> int:
    cfg = load_config(args.project)
    request = " ".join(args.request).strip()
    if not request:
        raise RuntimeError('Provide a request, for example: vibe "Add a customer search box"')

    print(f"Project: {cfg.project_root}")
    print(f"Model:   {cfg.model}")
    print(f"Region:  {cfg.region}")
    print("Asking OCI Generative AI Chat to inspect/build the project...")
    result = run_agent(cfg, request)

    print("\nOCI GenAI summary:\n")
    print(result.summary.strip())
    print(f"\nGenAI calls: {result.calls}")

    if not result.sandbox.staged:
        print("\nNo file changes were staged.")
        return 0

    print("\nStaged files:")
    for path in sorted(result.sandbox.staged):
        print(f"  {path}")

    diff = result.sandbox.diff()
    if not args.yes:
        print("\nProposed diff:\n")
        print(diff or "(No textual diff)")
        if not confirm("Apply these changes?", default=False):
            print("No files changed.")
            return 0

    backup = create_backup(cfg.project_root, cfg.backup_root)
    print(f"\nBackup created: {backup}")
    changed = result.sandbox.apply()
    register_app(cfg.project_root, cfg.registry_path)
    print("\nApplied:")
    for path in changed:
        print(f"  {path}")
    print("\nUse 'vibe restore' to roll back or 'vibe clean' to remove this generated app.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vibe",
        description="Constrained OCI Generative AI coding assistant for the Deep Data Security lab.",
    )
    parser.add_argument("--project", help="Override project root for this invocation.")
    sub = parser.add_subparsers(dest="command")

    p_backup = sub.add_parser("backup", help="Create a filesystem backup of the current application.")
    p_backup.set_defaults(func=cmd_backup)

    p_restore = sub.add_parser("restore", help="Restore the most recent filesystem backup for this app.")
    p_restore.add_argument("-y", "--yes", action="store_true", help="Do not prompt for confirmation.")
    p_restore.set_defaults(func=cmd_restore)

    p_reset = sub.add_parser("reset", help="Restore the protected known-good application copy.")
    p_reset.add_argument("-y", "--yes", action="store_true", help="Do not prompt for confirmation.")
    p_reset.set_defaults(func=cmd_reset)

    p_status = sub.add_parser("status", help="Show effective non-secret configuration.")
    p_status.set_defaults(func=cmd_status)

    p_apps = sub.add_parser("apps", help="List applications registered as Vibe-managed.")
    p_apps.set_defaults(func=cmd_apps)

    p_clean = sub.add_parser("clean", help="Delete the current Vibe-managed application safely.")
    p_clean.add_argument("--all", action="store_true", help="Delete all registered Vibe-managed applications.")
    p_clean.add_argument("--backups", action="store_true", help="Also delete backups for each cleaned application.")
    p_clean.add_argument("-y", "--yes", action="store_true", help="Do not prompt for confirmation.")
    p_clean.set_defaults(func=cmd_clean)

    p_run = sub.add_parser("run", help="Ask OCI GenAI to modify the application.")
    p_run.add_argument("request", nargs="+", help="Natural-language coding request.")
    p_run.add_argument("-y", "--yes", action="store_true", help="Apply the generated changes without prompting.")
    p_run.set_defaults(func=cmd_vibe)

    return parser


def main() -> None:
    argv = sys.argv[1:]
    known = {"backup", "restore", "reset", "status", "apps", "clean", "run", "-h", "--help"}
    if argv and argv[0] not in known and not argv[0].startswith("--project"):
        argv = ["run", *argv]

    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        raise SystemExit(2)
    try:
        raise SystemExit(args.func(args))
    except (RuntimeError, BackupError, RegistryError) as exc:
        print(f"vibe: error: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
