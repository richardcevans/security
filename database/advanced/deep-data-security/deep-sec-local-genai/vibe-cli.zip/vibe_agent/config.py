from __future__ import annotations

import os
import re
from typing import Optional
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.9/3.10
    import tomli as tomllib


DEFAULTS_FILE = Path("~/.deep-sec-genai-defaults").expanduser()
DEFAULT_PROJECT_ROOT = Path("/opt/deep-sec-customer-sales")
_ASSIGNMENT = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(["\']?)(.*?)\2\s*$')


@dataclass(frozen=True)
class Config:
    region: str
    compartment_ocid: str
    model: str
    project_root: Path
    backup_root: Path
    known_good_root: Path
    registry_path: Path
    max_file_bytes: int = 200_000
    max_project_bytes: int = 500_000
    max_output_tokens: int = 32_768


def _load_toml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("rb") as f:
        return tomllib.load(f)


def _load_shell_defaults(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = _ASSIGNMENT.match(line)
        if match:
            values[match.group(1)] = match.group(3)
    return values


def load_config(project_override: Optional[str] = None, require_project: bool = True) -> Config:
    config_path = Path(os.environ.get("VIBE_CONFIG", "~/.config/vibe/config.toml")).expanduser()
    raw = _load_toml(config_path)

    defaults_path = Path(
        os.environ.get("VIBE_GENAI_DEFAULTS_FILE", raw.get("genai_defaults_file", str(DEFAULTS_FILE)))
    ).expanduser()
    defaults = _load_shell_defaults(defaults_path)

    region = (
        os.environ.get("VIBE_REGION")
        or os.environ.get("OCI_REGION")
        or raw.get("region")
        or defaults.get("OCI_REGION")
        or "us-chicago-1"
    )
    compartment_ocid = (
        os.environ.get("VIBE_GENAI_COMPARTMENT_OCID")
        or os.environ.get("GENAI_COMPARTMENT_OCID")
        or raw.get("compartment_ocid")
        or defaults.get("GENAI_COMPARTMENT_OCID")
        or ""
    )
    model = (
        os.environ.get("VIBE_MODEL")
        or os.environ.get("GENAI_MODEL_ID")
        or raw.get("model")
        or defaults.get("GENAI_MODEL_ID")
        or ""
    )
    root_value = project_override or os.environ.get(
        "VIBE_PROJECT_ROOT", raw.get("project_root", str(DEFAULT_PROJECT_ROOT))
    )
    project_root = Path(root_value).expanduser().resolve()
    backup_root = Path(
        os.environ.get("VIBE_BACKUP_ROOT", raw.get("backup_root", "~/.vibe-backups"))
    ).expanduser().resolve()
    registry_path = Path(
        os.environ.get("VIBE_REGISTRY_PATH", raw.get("registry_path", "~/vibe-agent/apps.json"))
    ).expanduser().resolve()
    known_good_root = Path(
        os.environ.get(
            "VIBE_KNOWN_GOOD_ROOT",
            raw.get("known_good_root", str(project_root.parent / f"{project_root.name}-known-good")),
        )
    ).expanduser().resolve()
    max_file_bytes = int(os.environ.get("VIBE_MAX_FILE_BYTES", raw.get("max_file_bytes", 200_000)))
    max_project_bytes = int(os.environ.get("VIBE_MAX_PROJECT_BYTES", raw.get("max_project_bytes", 500_000)))
    max_output_tokens = int(os.environ.get("VIBE_MAX_OUTPUT_TOKENS", raw.get("max_output_tokens", 32_768)))

    if not compartment_ocid:
        raise RuntimeError(
            "Missing GenAI compartment OCID. Expected GENAI_COMPARTMENT_OCID in "
            f"{defaults_path}, or set VIBE_GENAI_COMPARTMENT_OCID / compartment_ocid in the Vibe config."
        )
    if not model:
        raise RuntimeError(
            "Missing GenAI model ID. Expected GENAI_MODEL_ID in "
            f"{defaults_path}, or set VIBE_MODEL / model in the Vibe config."
        )
    if require_project and not project_root.is_dir():
        raise RuntimeError(f"Project root does not exist: {project_root}")

    return Config(
        region=region,
        compartment_ocid=compartment_ocid,
        model=model,
        project_root=project_root,
        backup_root=backup_root,
        known_good_root=known_good_root,
        registry_path=registry_path,
        max_file_bytes=max_file_bytes,
        max_project_bytes=max_project_bytes,
        max_output_tokens=max_output_tokens,
    )
