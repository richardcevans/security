from __future__ import annotations

import difflib
import os
from pathlib import Path

DENIED_NAMES = {
    ".env",
    ".env.local",
    ".env.production",
    "cwallet.sso",
    "ewallet.p12",
    "keystore.jks",
    "ojdbc.properties",
    "sqlnet.ora",
    "tnsnames.ora",
    "truststore.jks",
}
DENIED_SUFFIXES = {".key", ".pem", ".p12", ".pfx", ".jks"}
IGNORED_DIRS = {
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    "node_modules", "dist", "build", ".idea", ".vscode"
}


class SandboxError(RuntimeError):
    pass


class ProjectSandbox:
    def __init__(self, root: Path, max_file_bytes: int = 200_000):
        self.root = root.resolve()
        self.max_file_bytes = max_file_bytes
        self.staged: dict[str, str] = {}

    def _normalize(self, relative_path: str) -> tuple[str, Path]:
        if not relative_path or relative_path.startswith("~"):
            raise SandboxError("Path must be relative to the project root.")
        candidate = (self.root / relative_path).resolve()
        try:
            rel = candidate.relative_to(self.root)
        except ValueError as exc:
            raise SandboxError("Path escapes the project root.") from exc

        parts = rel.parts
        if any(part in IGNORED_DIRS for part in parts):
            raise SandboxError("Path is in an ignored directory.")
        if rel.name in DENIED_NAMES or rel.suffix.lower() in DENIED_SUFFIXES:
            raise SandboxError(f"Access denied for sensitive file: {rel}")
        return rel.as_posix(), candidate

    def list_files(self) -> list[str]:
        results: list[str] = []
        for path in self.root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(self.root)
            if any(part in IGNORED_DIRS for part in rel.parts):
                continue
            try:
                normalized, _ = self._normalize(rel.as_posix())
            except SandboxError:
                continue
            if path.stat().st_size <= self.max_file_bytes:
                results.append(normalized)
        for path in self.staged:
            if path not in results:
                results.append(path)
        return sorted(results)

    def read_file(self, relative_path: str) -> str:
        rel, path = self._normalize(relative_path)
        if rel in self.staged:
            return self.staged[rel]
        if not path.exists() or not path.is_file():
            raise SandboxError(f"File does not exist: {rel}")
        if path.stat().st_size > self.max_file_bytes:
            raise SandboxError(f"File exceeds {self.max_file_bytes} bytes: {rel}")
        try:
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise SandboxError(f"File is not UTF-8 text: {rel}") from exc

    def stage_write(self, relative_path: str, content: str) -> str:
        rel, _ = self._normalize(relative_path)
        encoded = content.encode("utf-8")
        if len(encoded) > self.max_file_bytes:
            raise SandboxError(f"Proposed file exceeds {self.max_file_bytes} bytes: {rel}")
        self.staged[rel] = content
        return rel

    def diff(self) -> str:
        chunks: list[str] = []
        for rel in sorted(self.staged):
            _, path = self._normalize(rel)
            old = ""
            if path.exists() and path.is_file():
                try:
                    old = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    old = ""
            new = self.staged[rel]
            diff = difflib.unified_diff(
                old.splitlines(keepends=True),
                new.splitlines(keepends=True),
                fromfile=f"a/{rel}",
                tofile=f"b/{rel}",
            )
            chunks.append("".join(diff))
        return "\n".join(chunk for chunk in chunks if chunk)

    def apply(self) -> list[str]:
        changed: list[str] = []
        for rel, content in self.staged.items():
            _, path = self._normalize(rel)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            if path.suffix == ".sh":
                path.chmod(0o755)
            changed.append(rel)
        return sorted(changed)
