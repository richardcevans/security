# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/oracle/oci" {
  version     = "8.22.0"
  constraints = ">= 6.0.0"
  hashes = [
    "h1:UKLe8ehf7l9y2/eOnSIOduh4zVYraAfOBxjFwyRLt6Q=",
    "zh:0006fcdb52d37285b73c83e91cb5e298b05a6935a15ea865e83a5529ecaef868",
    "zh:249e76d8a172e11e5e06f77663541537c4c216b847e8d624bb5a9f32529e0aec",
    "zh:3cf68a19afd7fa3ffa5506025a262d94772177ed3d3f1004eeaeaec4ab197c22",
    "zh:3f488e5a32374e3a5d9953023c27e4b21d113800c9a50247092f0220316453db",
    "zh:6dca79b3f8fd2c2b6841ba63cb7ac3e673cd334ffc8937c651588edfc87dcc90",
    "zh:7263f3973d49cf80d88b8ec60c42cf81cd2a060281a6f8ac8500b64ae41b20a3",
    "zh:7ca0fd995a102ce1852000dbb9601609e559adf8e34606237e6c3cf5d94caa7e",
    "zh:7e11709bcb11076141b8df41084573159de8b663ffb8345ccbd380768a1b2d82",
    "zh:90782c215c3671cfc9d6ee853af8cd16c0fdd8c817b2672bc001b2d57a2bcb65",
    "zh:9b12af85486a96aedd8d7984b0ff811a4b42e3d88dad1a3fb4c0b580d04fa425",
    "zh:a083575c5047062f162b9fffe078852ca0f44bf0293275038fe22d29f67a655a",
    "zh:b2709a6a63e7510e869a0ff2c6f688b4a3d9e24f7a92588b8bad19d74b4c8892",
    "zh:b403b916a94a2d782b44286f958e90c6efd6e97def7772059d1a0ef028eb0480",
    "zh:b787c10f06889433c9f559a0961b7548f49fd826129c279f3301aa1df5f95074",
    "zh:f234bd1b208ebe25cdfe4edb9b3665d3055f7a8df0ea00d6f10a9ea1ceb99455",
  ]
}
