#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENTRA_LAB_ENV="${ENTRA_LAB_ENV:-${SCRIPT_DIR}/../entra-id-data-grants/.entra-id-data-grants.env}"

if [ -f "$ENTRA_LAB_ENV" ]; then
  # shellcheck disable=SC1090
  source "$ENTRA_LAB_ENV"
fi

: "${PDB_NAME:?PDB_NAME is required}"
DB_SID="${DB_SID:-FREE}"
export ORACLE_SID="$DB_SID"

echo "Configuring Unified Audit policy for HR.EMPLOYEES in PDB ${PDB_NAME}"
echo
echo "This script will replace WEB_HR_APP_EMPLOYEE_AUDIT, enable it,"
echo "and grant AUDIT_VIEWER to WEB_HR_APP_USER."

sqlplus -s / as sysdba <<EOF
set echo off
set serveroutput on
set lines 180
set pages 9999
whenever sqlerror exit sql.sqlcode

ALTER SESSION SET CONTAINER = ${PDB_NAME};

prompt
prompt ========================================================================
prompt Replace Web HR App employee audit policy
prompt ========================================================================
prompt Disabling and dropping WEB_HR_APP_EMPLOYEE_AUDIT if it already exists.

BEGIN
  BEGIN
    EXECUTE IMMEDIATE 'NOAUDIT POLICY web_hr_app_employee_audit';
    DBMS_OUTPUT.PUT_LINE('Disabled existing WEB_HR_APP_EMPLOYEE_AUDIT policy.');
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('No existing enabled WEB_HR_APP_EMPLOYEE_AUDIT policy to disable.');
  END;
  BEGIN
    EXECUTE IMMEDIATE 'DROP AUDIT POLICY web_hr_app_employee_audit';
    DBMS_OUTPUT.PUT_LINE('Dropped existing WEB_HR_APP_EMPLOYEE_AUDIT policy.');
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('No existing WEB_HR_APP_EMPLOYEE_AUDIT policy to drop.');
  END;
END;
/

prompt Creating WEB_HR_APP_EMPLOYEE_AUDIT for SELECT and UPDATE on HR.EMPLOYEES.
CREATE AUDIT POLICY web_hr_app_employee_audit
  ACTIONS SELECT ON hr.employees,
          UPDATE ON hr.employees;

prompt Enabling WEB_HR_APP_EMPLOYEE_AUDIT.
AUDIT POLICY web_hr_app_employee_audit;

prompt Granting AUDIT_VIEWER to WEB_HR_APP_USER so the app can show Unified Audit records.
GRANT AUDIT_VIEWER TO web_hr_app_user;

prompt
prompt ========================================================================
prompt Web HR App employee audit policy enabled
prompt ========================================================================

col policy_name format a32
SELECT policy_name, audit_option, object_schema, object_name
  FROM audit_unified_policies
 WHERE policy_name = 'WEB_HR_APP_EMPLOYEE_AUDIT'
 ORDER BY audit_option;

prompt
prompt Run app SELECT/UPDATE actions, then refresh the app audit panel or query:
prompt
prompt SELECT event_timestamp, dbusername, end_user_name, userhost, client_program_name,
prompt        action_name, return_code, DBMS_LOB.SUBSTR(sql_text, 100, 1) AS sql_text_preview
prompt   FROM unified_audit_trail
prompt  WHERE object_schema = 'HR'
prompt    AND object_name = 'EMPLOYEES'
prompt    AND action_name IN ('SELECT', 'UPDATE')
prompt    AND event_timestamp >= SYSTIMESTAMP - INTERVAL '3' MINUTE
prompt  ORDER BY event_timestamp DESC;

prompt
prompt The web app queries UNIFIED_AUDIT_TRAIL through the AUDIT_VIEWER role.

exit;
EOF

echo
echo "Unified Audit policy configured."
