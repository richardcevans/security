#!/bin/bash
# Create the local environment file used by the optional DeepSec MCP scripts.
# This script does not create OCI resources. For the automated ADB-S path, run
# setup_adbs_oci_iam.sh instead so the env file contains real database values.

set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m'

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ENV_FILE="${SCRIPT_DIR}/.deep-sec-mcp.env"

usage() {
  cat <<'EOF'
Usage:
  ./00_configure_lab_env.sh

Set values with environment variables before running, or edit .deep-sec-mcp.env
after the script creates it.

Common values:
  DB_NAME                          Autonomous Database name
  ADB_OCID                         Autonomous Database OCID
  ADB_SERVICE                      TNS service, for example deepsec1_low
  ADMIN_PWD                        ADMIN password
  WALLET_DIR                       Local wallet directory
  TNS_ADMIN                        Usually same as WALLET_DIR
  OCI_DOMAIN_URL                   Identity domain URL
  OCI_DB_APP_ID                    DB resource app OCID
  OCI_DB_CLIENT_ID                 DB resource app client id
  OCI_DB_CLIENT_SECRET             DB resource app client secret
  OCI_CLIENT_ID                    OAuth public/confidential client id
  OCI_CLIENT_SECRET                Optional OAuth client secret
  OCI_SCOPE                        Database OAuth scope
  DATA_ROLE_MAPPING_TYPE           IAM_GROUP_NAME for MCP/PoP token path or IAM_OAUTH_GROUP for direct OAuth SQL
  OCI_IAM_EMPLOYEE_GROUP           Employee group name
  OCI_IAM_MANAGER_GROUP            Manager group name
  MARVIN_USERNAME                  Manager test user
  EMMA_USERNAME                    Employee test user
  DATABASE_TOOLS_CONNECTION_ID     Existing Database Tools connection OCID
  DATABASE_TOOLS_CONNECTION_STRING Database connect string for Database Tools
  DATABASE_TOOLS_CONNECTION_NAME   Display name for a new Database Tools connection
  DATABASE_TOOLS_CONNECTION_AUTHENTICATION_TYPE TOKEN or PASSWORD
  DATABASE_TOOLS_PASSWORD_SECRET_OCID Vault secret OCID for PASSWORD mode
  DATABASE_TOOLS_RUNTIME_IDENTITY AUTHENTICATED_PRINCIPAL or RESOURCE_PRINCIPAL
  MCP_SERVER_ID                    Existing MCP server OCID
  MCP_SERVER_NAME                  Display name for a new MCP server
  MCP_SERVER_ENDPOINT              MCP server endpoint URL
  MCP_RUNTIME_IDENTITY             AUTHENTICATED_PRINCIPAL or RESOURCE_PRINCIPAL
  MCP_CREATE_BUILT_IN_SQL_TOOLSET  1 to create built-in SQL tools
  MCP_BUILT_IN_SQL_TOOLSET_VERSION Toolset version, default 1
  MCP_COMPARTMENT_NAME             Optional compartment display name for discovery
  MCP_IDENTITY_DOMAIN_NAME         Optional identity domain display name for discovery

Optional wallet download:
  DOWNLOAD_WALLET=1 ADB_OCID=<ocid> ADMIN_PWD=<password> ./00_configure_lab_env.sh
EOF
}

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then
  usage
  exit 0
fi

show_cmd() {
  printf '  $'
  printf ' %q' "$@"
  printf '\n'
}

write_env() {
  umask 077
  cat > "$ENV_FILE" <<EOF
# DeepSec MCP optional command environment.
# Source with: source ./.deep-sec-mcp.env

export DB_NAME="${DB_NAME:-}"
export ADB_OCID="${ADB_OCID:-}"
export ADB_SERVICE="${ADB_SERVICE:-}"
export ADMIN_PWD="${ADMIN_PWD:-}"
export WALLET_DIR="${WALLET_DIR:-}"
export TNS_ADMIN="${TNS_ADMIN:-${WALLET_DIR:-}}"
export WALLET_PWD="${WALLET_PWD:-Oracle123+}"

export OCI_DOMAIN_URL="${OCI_DOMAIN_URL:-}"
export OCI_DB_APP_ID="${OCI_DB_APP_ID:-}"
export OCI_DB_CLIENT_ID="${OCI_DB_CLIENT_ID:-}"
export OCI_DB_CLIENT_SECRET="${OCI_DB_CLIENT_SECRET:-}"
export OCI_CLIENT_ID="${OCI_CLIENT_ID:-}"
export OCI_CLIENT_SECRET="${OCI_CLIENT_SECRET:-}"
export OCI_SCOPE="${OCI_SCOPE:-}"
export OCI_REDIRECT_URI="${OCI_REDIRECT_URI:-http://localhost:8888/callback}"
export OCI_TOKEN_DIR="${OCI_TOKEN_DIR:-$HOME/.oci/deep-sec-mcp}"

export DATA_ROLE_MAPPING_TYPE="${DATA_ROLE_MAPPING_TYPE:-IAM_GROUP_NAME}"
export OCI_IAM_EMPLOYEE_GROUP="${OCI_IAM_EMPLOYEE_GROUP:-example-domain/deepsec-employees}"
export OCI_IAM_MANAGER_GROUP="${OCI_IAM_MANAGER_GROUP:-example-domain/deepsec-managers}"
export OCI_USERNAME_DOMAIN="${OCI_USERNAME_DOMAIN:-}"
export MARVIN_USERNAME="${MARVIN_USERNAME:-marvin}"
export EMMA_USERNAME="${EMMA_USERNAME:-emma}"

export DATABASE_TOOLS_CONNECTION_ID="${DATABASE_TOOLS_CONNECTION_ID:-}"
export DATABASE_TOOLS_CONNECTION_STRING="${DATABASE_TOOLS_CONNECTION_STRING:-}"
export DATABASE_TOOLS_CONNECTION_NAME="${DATABASE_TOOLS_CONNECTION_NAME:-deep-sec-mcp-connection}"
export DATABASE_TOOLS_CONNECTION_AUTHENTICATION_TYPE="${DATABASE_TOOLS_CONNECTION_AUTHENTICATION_TYPE:-TOKEN}"
export DATABASE_TOOLS_CONNECTION_USER_NAME="${DATABASE_TOOLS_CONNECTION_USER_NAME:-}"
export DATABASE_TOOLS_PASSWORD_SECRET_OCID="${DATABASE_TOOLS_PASSWORD_SECRET_OCID:-}"
export DATABASE_TOOLS_PRIVATE_ENDPOINT_OCID="${DATABASE_TOOLS_PRIVATE_ENDPOINT_OCID:-}"
export DATABASE_TOOLS_RELATED_RESOURCE_TYPE="${DATABASE_TOOLS_RELATED_RESOURCE_TYPE:-}"
export DATABASE_TOOLS_RELATED_RESOURCE_OCID="${DATABASE_TOOLS_RELATED_RESOURCE_OCID:-}"
if [ "${DATABASE_TOOLS_CONNECTION_AUTHENTICATION_TYPE}" = "TOKEN" ]; then
  export DATABASE_TOOLS_RUNTIME_IDENTITY="RESOURCE_PRINCIPAL"
else
  export DATABASE_TOOLS_RUNTIME_IDENTITY="${DATABASE_TOOLS_RUNTIME_IDENTITY:-AUTHENTICATED_PRINCIPAL}"
fi
export MCP_SERVER_ID="${MCP_SERVER_ID:-}"
export MCP_SERVER_NAME="${MCP_SERVER_NAME:-deep-sec-mcp}"
export MCP_SERVER_ENDPOINT="${MCP_SERVER_ENDPOINT:-}"
if [ "${DATABASE_TOOLS_CONNECTION_AUTHENTICATION_TYPE}" = "TOKEN" ]; then
  export MCP_RUNTIME_IDENTITY="AUTHENTICATED_PRINCIPAL"
else
  export MCP_RUNTIME_IDENTITY="${MCP_RUNTIME_IDENTITY:-RESOURCE_PRINCIPAL}"
fi
export MCP_CREATE_BUILT_IN_SQL_TOOLSET="${MCP_CREATE_BUILT_IN_SQL_TOOLSET:-1}"
export MCP_BUILT_IN_SQL_TOOLSET_NAME="${MCP_BUILT_IN_SQL_TOOLSET_NAME:-deep-sec-mcp-built-in-sql-tools}"
export MCP_BUILT_IN_SQL_TOOLSET_VERSION="${MCP_BUILT_IN_SQL_TOOLSET_VERSION:-1}"
export MCP_BUILT_IN_SQL_TOOLSET_ID="${MCP_BUILT_IN_SQL_TOOLSET_ID:-}"
export MCP_BUCKET_NAME="${MCP_BUCKET_NAME:-}"
export MCP_COMPARTMENT_OCID="${MCP_COMPARTMENT_OCID:-}"
export MCP_COMPARTMENT_NAME="${MCP_COMPARTMENT_NAME:-}"
export MCP_IDENTITY_DOMAIN_OCID="${MCP_IDENTITY_DOMAIN_OCID:-}"
export MCP_IDENTITY_DOMAIN_NAME="${MCP_IDENTITY_DOMAIN_NAME:-}"
export TENANCY_OCID="${TENANCY_OCID:-}"
export NAMESPACE="${NAMESPACE:-}"
EOF
}

download_wallet() {
  if [ "${DOWNLOAD_WALLET:-0}" != "1" ]; then
    return 0
  fi

  if [ -z "${ADB_OCID:-}" ]; then
    echo -e "${RED}ERROR: ADB_OCID is required when DOWNLOAD_WALLET=1.${NC}" >&2
    exit 1
  fi
  if [ -z "${DB_NAME:-}" ]; then
    echo -e "${RED}ERROR: DB_NAME is required when DOWNLOAD_WALLET=1.${NC}" >&2
    exit 1
  fi

  if ! command -v oci >/dev/null 2>&1; then
    echo -e "${RED}ERROR: OCI CLI is required to download the wallet.${NC}" >&2
    exit 1
  fi

  if ! command -v unzip >/dev/null 2>&1; then
    echo -e "${RED}ERROR: unzip is required to extract the wallet.${NC}" >&2
    exit 1
  fi

  mkdir -p "${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}"
  local wallet_zip="${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}/wallet.zip"

  echo -e "${CYAN}Downloading wallet to ${wallet_zip}${NC}"
  show_cmd oci db autonomous-database generate-wallet --autonomous-database-id "$ADB_OCID" --password '<hidden>' --file "$wallet_zip"
  oci db autonomous-database generate-wallet \
    --autonomous-database-id "$ADB_OCID" \
    --password "${WALLET_PWD:-Oracle123+}" \
    --file "$wallet_zip"

  unzip -o "$wallet_zip" -d "${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}" >/dev/null

  if [ -f "${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}/sqlnet.ora" ]; then
    perl -pi -e "s|DIRECTORY=\\\"\\?/network/admin\\\"|DIRECTORY=\\\"${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}\\\"|g" \
      "${WALLET_DIR:-$HOME/adb_wallet/${DB_NAME:-deepsec1}}/sqlnet.ora"
  fi
}

echo
echo -e "${GREEN}============================================================================${NC}"
echo -e "${GREEN}      Configure DeepSec MCP Optional Script Environment                      ${NC}"
echo -e "${GREEN}============================================================================${NC}"
echo

download_wallet
write_env

echo -e "${GREEN}Created ${ENV_FILE}${NC}"
echo
echo -e "${YELLOW}Next:${NC}"
echo "  For the automated ADB-S path:"
echo "    ./setup_adbs_oci_iam.sh <compartment-name-or-ocid>"
echo "    source ./.deep-sec-mcp.env"
echo "    ./02_create_hr_schema.sh"
echo
echo "  For an existing manually configured database, edit .deep-sec-mcp.env first"
echo "  and set DB_NAME, ADB_SERVICE, ADMIN_PWD, WALLET_DIR, and TNS_ADMIN."
echo
